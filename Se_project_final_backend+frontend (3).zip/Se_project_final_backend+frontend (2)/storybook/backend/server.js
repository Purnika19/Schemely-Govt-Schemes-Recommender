const express = require("express");
const fs = require("fs");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Load or create users.json
let users = [];
if (fs.existsSync("users.json")) {
    users = JSON.parse(fs.readFileSync("users.json"));
}

// ---------- SIGNUP ----------
app.post("/signup", (req, res) => {
    const { name, email, password } = req.body;

    const exists = users.find(u => u.email === email);
    if (exists) {
        return res.json({ ok: false, msg: "Email is already registered!" });
    }

    users.push({ name, email, password });
    fs.writeFileSync("users.json", JSON.stringify(users, null, 2));

    res.json({ ok: true, msg: "Account Created Successfully!" });
});

// ---------- LOGIN ----------
app.post("/login", (req, res) => {
    const { email, password } = req.body;

    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
        return res.json({ ok: true, msg: "Login Successful!" });
    }

    return res.json({ ok: false, msg: "Invalid email or password" });
});

// START SERVER
app.listen(5000, () => {
    console.log("Backend running at http://localhost:5000");
});
